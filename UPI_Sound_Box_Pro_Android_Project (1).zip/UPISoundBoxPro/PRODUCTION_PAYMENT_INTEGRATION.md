# Production payment verification integration checklist

The Android starter cannot confirm settlement from a static UPI QR by itself. A production deployment needs an acquiring bank, payment gateway, or merchant UPI provider with an official API/webhook.

Required server-side flow:
1. Create a merchant order/payment intent with the provider.
2. Bind the provider's transaction/order reference to the merchant and expected amount.
3. Receive provider webhook on HTTPS.
4. Verify the provider signature using a server-held secret/public key.
5. Fetch/confirm final transaction status with provider API when required.
6. Match merchant account/VPA, currency INR, amount, order ID and final successful state.
7. Deduplicate by provider transaction ID; reject replays and amount mismatches.
8. Notify the Android app over authenticated push/polling only after verification.
9. Keep secrets on the server; never trust an Android client-supplied success flag.

Provider-specific credentials, webhook URLs, callback schema and merchant onboarding must be supplied by the merchant/provider. Do not assume that a consumer UPI app exposes a public payment verification API.
