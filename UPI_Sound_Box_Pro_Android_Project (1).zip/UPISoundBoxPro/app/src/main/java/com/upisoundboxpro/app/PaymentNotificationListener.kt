package com.upisoundboxpro.app

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Announces matching incoming-payment notifications from common UPI apps.
 * This is a convenience alert, NOT bank-grade payment verification.
 */
class PaymentNotificationListener : NotificationListenerService(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val supportedPackages = setOf(
        "com.google.android.apps.nbu.paisa.user", // Google Pay
        "com.phonepe.app",                       // PhonePe
        "net.one97.paytm",                       // Paytm
        "in.org.npci.upiapp"                     // BHIM
    )

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(applicationContext, this)
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.setLanguage(Locale("hi", "IN"))
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in supportedPackages) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val text = listOf(title, body, big).filter { it.isNotBlank() }.distinct().joinToString(". ")
        if (text.isBlank()) return

        val lower = text.lowercase(Locale.ROOT)
        val incomingWords = listOf("received", "credited", "has paid", "paid you", "payment from", "money received", " जमा", "प्राप्त", "जमा हुए", "भेजे")
        val outgoingWords = listOf("debited", "sent to", "you paid", "payment to", " पैसा भेजा", "निकाले")
        if (incomingWords.none { lower.contains(it) } || outgoingWords.any { lower.contains(it) }) return

        val amountMatch = Regex("(?:₹|rs\\.?\\s?|inr\\s*)([0-9,]+(?:\\.[0-9]{1,2})?)", RegexOption.IGNORE_CASE).find(text)
            ?: Regex("([0-9,]+(?:\\.[0-9]{1,2})?)\\s*(?:rupees|रुपये|रु)", RegexOption.IGNORE_CASE).find(text)
            ?: return
        val amount = amountMatch.groupValues[1].replace(",", "")
        val key = "${sbn.packageName}:${sbn.key}:$amount:${sbn.postTime}"
        if (!seen.add(key)) return
        if (seen.size > 300) seen.clear()

        val sender = Regex("(?:from|by)\\s+([A-Za-z][A-Za-z .]{1,30})", RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1)?.trim()
        val announcement = if (sender.isNullOrBlank()) "₹$amount payment received" else "₹$amount received from $sender"
        val line = "₹$amount • ${sbn.packageName.substringAfterLast('.') }"
        sendBroadcast(Intent(ACTION_PAYMENT_ALERT).setPackage(packageName).putExtra(EXTRA_LINE, line))
        if (ttsReady) {
            val preferences = getSharedPreferences("merchant", MODE_PRIVATE)
            val languageMode = preferences.getInt("language_mode", 2)
            val volume = (preferences.getInt("volume", 100).coerceIn(0, 100) / 100f)
            val speed = 0.5f + preferences.getInt("speech_speed", 5).coerceIn(0, 15) * 0.1f
            tts?.setSpeechRate(speed)
            val params = android.os.Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume)
            }
            when (languageMode) {
                0 -> {
                    tts?.setLanguage(Locale("hi", "IN"))
                    tts?.speak("$announcement. भुगतान प्राप्त हुआ।", TextToSpeech.QUEUE_ADD, params, key)
                }
                1 -> {
                    tts?.setLanguage(Locale.US)
                    tts?.speak("$announcement. Payment received.", TextToSpeech.QUEUE_ADD, params, key)
                }
                else -> {
                    tts?.setLanguage(Locale.US)
                    tts?.speak("$announcement. Payment received.", TextToSpeech.QUEUE_ADD, params, "${key}_en")
                    tts?.setLanguage(Locale("hi", "IN"))
                    tts?.speak("भुगतान प्राप्त हुआ।", TextToSpeech.QUEUE_ADD, params, "${key}_hi")
                }
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_PAYMENT_ALERT = "com.upisoundboxpro.app.PAYMENT_ALERT"
        const val ACTION_TEST_VOICE = "com.upisoundboxpro.app.TEST_VOICE"
        const val EXTRA_LINE = "line"
        const val EXTRA_LANGUAGE = "language"
    }
}
