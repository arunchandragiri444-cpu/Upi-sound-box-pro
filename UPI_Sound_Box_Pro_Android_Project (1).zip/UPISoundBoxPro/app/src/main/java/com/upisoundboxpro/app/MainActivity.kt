package com.upisoundboxpro.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("merchant", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var lastPayment: TextView
    private lateinit var history: TextView
    private lateinit var qrImage: ImageView
    private var testTts: android.speech.tts.TextToSpeech? = null
    private val paymentReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val line = intent?.getStringExtra(PaymentNotificationListener.EXTRA_LINE) ?: return
            lastPayment.text = line
            val old = prefs.getString("history", "No payment alerts yet.") ?: ""
            history.text = ("$line\n$old").take(2500)
            prefs.edit().putString("history", history.text.toString()).apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText)
        lastPayment = findViewById(R.id.lastPaymentText)
        history = findViewById(R.id.historyText)
        qrImage = findViewById(R.id.qrImage)
        val shop = findViewById<EditText>(R.id.shopNameInput)
        val upi = findViewById<EditText>(R.id.upiIdInput)
        shop.setText(prefs.getString("shop", ""))
        upi.setText(prefs.getString("upi", ""))
        history.text = prefs.getString("history", "No payment alerts yet.")

        val languageSpinner = findViewById<Spinner>(R.id.languageSpinner)
        languageSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Hindi", "English", "Hindi + English"))
        languageSpinner.setSelection(prefs.getInt("language_mode", 2))
        languageSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                prefs.edit().putInt("language_mode", position).apply()
            }
        }
        val volume = findViewById<SeekBar>(R.id.volumeSeekBar)
        val volumeLabel = findViewById<TextView>(R.id.volumeLabel)
        volume.progress = prefs.getInt("volume", 100)
        volumeLabel.text = "Volume: ${volume.progress}%"
        volume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                volumeLabel.text = "Volume: $progress%"
                prefs.edit().putInt("volume", progress).apply()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        val speed = findViewById<SeekBar>(R.id.speedSeekBar)
        val speedLabel = findViewById<TextView>(R.id.speedLabel)
        speed.progress = prefs.getInt("speech_speed", 5).coerceIn(0, 15)
        speedLabel.text = "Speech speed: ${String.format(java.util.Locale.US, "%.1fx", 0.5f + speed.progress * 0.1f)}"
        speed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                speedLabel.text = "Speech speed: ${String.format(java.util.Locale.US, "%.1fx", 0.5f + progress * 0.1f)}"
                prefs.edit().putInt("speech_speed", progress).apply()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        findViewById<Button>(R.id.accessButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<Button>(R.id.saveButton).setOnClickListener {
            val shopName = shop.text.toString().trim()
            val upiId = upi.text.toString().trim()
            if (shopName.isBlank() || !upiId.matches(Regex("[A-Za-z0-9._-]{2,256}@[A-Za-z0-9.-]{2,64}"))) {
                Toast.makeText(this, "Enter shop name and a valid UPI ID", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit().putString("shop", shopName).putString("upi", upiId).apply()
                Toast.makeText(this, "Merchant details saved", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.qrButton).setOnClickListener {
            val upiId = upi.text.toString().trim()
            val shopName = shop.text.toString().trim()
            if (!upiId.matches(Regex("[A-Za-z0-9._-]{2,256}@[A-Za-z0-9.-]{2,64}"))) {
                Toast.makeText(this, "Save a valid UPI ID first", Toast.LENGTH_LONG).show()
            } else {
                try {
                    val uri = "upi://pay?pa=${upiId.encodeUri()}&pn=${shopName.ifBlank { "Merchant" }.encodeUri()}&cu=INR"
                    val matrix = QRCodeWriter().encode(uri, BarcodeFormat.QR_CODE, 640, 640)
                    val bitmap = Bitmap.createBitmap(640, 640, Bitmap.Config.RGB_565)
                    for (x in 0 until 640) for (y in 0 until 640) bitmap.setPixel(x, y, if (matrix[x, y]) 0xFF071525.toInt() else 0xFFFFFFFF.toInt())
                    qrImage.setImageBitmap(bitmap)
                    qrImage.visibility = ImageView.VISIBLE
                } catch (_: Exception) {
                    Toast.makeText(this, "Could not create QR code", Toast.LENGTH_SHORT).show()
                }
            }
        }
        findViewById<Button>(R.id.testHindiButton).setOnClickListener { speakTest("hi", "आपकी दुकान में आपका स्वागत है।") }
        findViewById<Button>(R.id.testEnglishButton).setOnClickListener { speakTest("en", "Welcome to our store.") }
        requestNotificationPermission()
        refreshAccessStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshAccessStatus()
        val filter = IntentFilter(PaymentNotificationListener.ACTION_PAYMENT_ALERT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(paymentReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(paymentReceiver, filter)
    }

    override fun onPause() {
        try { unregisterReceiver(paymentReceiver) } catch (_: Exception) {}
        super.onPause()
    }

    private fun refreshAccessStatus() {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        status.text = if (enabled) "Payment notification access is enabled" else "Notification access not enabled"
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun speakTest(language: String, message: String) {
        testTts?.shutdown()
        testTts = android.speech.tts.TextToSpeech(this) { result ->
            val engine = testTts ?: return@TextToSpeech
            if (result == android.speech.tts.TextToSpeech.SUCCESS) {
                val locale = if (language == "hi") java.util.Locale("hi", "IN") else java.util.Locale.US
                val availability = engine.setLanguage(locale)
                if (availability >= android.speech.tts.TextToSpeech.LANG_AVAILABLE) {
                    engine.speak(message, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "voice-test")
                } else {
                    Toast.makeText(this, "Selected voice is not available on this phone", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Text-to-speech is unavailable", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        testTts?.stop()
        testTts?.shutdown()
        testTts = null
        super.onDestroy()
    }

    private fun String.encodeUri(): String = java.net.URLEncoder.encode(this, "UTF-8")
}
