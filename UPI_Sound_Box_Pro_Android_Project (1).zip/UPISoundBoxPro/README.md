# UPI Sound Box Pro — Android project

An original Kotlin Android app inspired by the publicly described workflow of the user's reference app, **Soundbox – UPI Mobile Alerts**. It implements the same core concept without copying the reference app's branding, artwork, or proprietary code.

## Implemented in this project
- Notification-listener based alerts for Google Pay, PhonePe, Paytm and BHIM package IDs.
- Local text-to-speech announcements when matching incoming-payment notification text is detected.
- Announcement language selector: Hindi, English, or Hindi + English.
- Speech volume and speech-rate controls, saved locally.
- Recent alert activity shown in the app and saved in app-private preferences.
- Merchant shop name and UPI ID setup.
- Static UPI payment QR generation (an additional utility; it is not a payment gateway).
- Hindi and English voice test buttons.
- Explicit Android notification-access setup flow.

## Important limitations — read before using for business
1. This version reads notification text. It does not receive a bank/UPI settlement callback and cannot independently verify that money reached the merchant account.
2. It cannot announce a payment if the payer app/device does not post a notification, notification content is hidden, Android restricts background operation, or the notification format is not recognized.
3. The supported app package IDs and keyword/amount parser are best-effort. UPI app versions, languages, device vendors and notification formats vary. Test on the exact phones and app versions you plan to use.
4. The activity history is based on detected notifications, not a bank statement. Do not treat the displayed alerts or totals as proof of settlement.
5. For a production-grade merchant soundbox, integrate a payment aggregator/acquiring bank's documented server-side payment-status API or signed webhook. Verify signatures and transaction status on a backend; never put provider secrets in the APK.
6. The app does not copy the reference app's logo, artwork, source code or proprietary assets.

## Build
1. Install Android Studio and Android SDK Platform 35.
2. Open this `UPISoundBoxPro` folder in Android Studio.
3. Let Gradle sync and install any requested SDK components.
4. Run the `app` configuration on a physical Android phone.
5. To create an APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Project configuration: Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile/target SDK 35, min SDK 23. Java 17 is recommended.

## First run
1. Save your shop name and UPI ID.
2. Optionally generate your static UPI QR.
3. Tap **Enable Payment Alert Access** and explicitly enable notification access for UPI Sound Box Pro in Android Settings.
4. Grant notification permission if prompted.
5. Choose Hindi, English, or Hindi + English and set volume/speed.
6. Make a genuine small test payment and confirm the payer app produces a supported incoming-payment notification.

## Privacy
Notification-listener access is powerful: Android may expose notification content from other apps. This sample processes supported UPI notification text locally and stores a short alert history in app-private preferences. It does not upload notification content. Only grant notification access if you understand and accept this permission.
