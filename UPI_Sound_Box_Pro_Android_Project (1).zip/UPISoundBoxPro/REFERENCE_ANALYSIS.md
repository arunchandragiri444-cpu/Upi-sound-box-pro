# Reference app analysis

Reference: https://play.google.com/store/apps/details?id=in.mysoundbox.app

The Google Play listing describes Soundbox – UPI Mobile Alerts as a phone-based soundbox that reads supported UPI payment notifications aloud. It names Paytm, PhonePe, Google Pay and BHIM; explains that the app does not process payments; and describes a recent announcement/activity view plus volume and speech-speed controls. Its screenshots also market no additional hardware, payment announcements, transaction tracking, and compatibility with multiple UPI apps.

UPI Sound Box Pro implements the core notification-to-speech workflow and adds local merchant QR setup plus a Hindi/English language selector. This project is an independent implementation: it does not copy the reference app's source, logo, artwork, exact UI, or proprietary assets.

Important distinction: this starter project can only record notifications it detects. It does not have the reference developer's backend, payment-provider integration, subscription system, or any bank-grade settlement verification. A genuine verified transaction ledger requires a merchant payment provider API/webhook and a secure backend.
